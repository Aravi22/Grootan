package com.example.Userdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserdbApplicationTests {

	@Test
	void contextLoads() {
	}

}
