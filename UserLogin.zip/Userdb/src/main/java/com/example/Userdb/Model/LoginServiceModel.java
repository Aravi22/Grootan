package com.example.Userdb.Model;

import jdk.nashorn.internal.ir.annotations.Immutable;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
@Table(name="login")
public class LoginServiceModel {
    @Id
    @Column(name="id")
    private String id;
    @Column(name="UserName")
    private String phoneNumber;
    @Column(name="password")
    private String password;


}
