package com.example.Userdb.Service;

import com.example.Userdb.CreateUser.LoginDetails;
import com.example.Userdb.repository.LoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LoginServiceImplementation implements LoginService {
    @Autowired
   LoginDetails loginDetails;
    @Autowired
    LoginRepository loginRepository;

@Override
    public String login(LoginDetails loginDetails1)throws Exception {
  Optional<LoginDetails> listOfIds = loginRepository.findById(loginDetails1.getId());
  for (LoginDetails list : listOfIds) {
    if (list.getUserName().equals(loginDetails1.getUserName())) {
      if (list.getPassword().equals(loginDetails1.getPassword()))
        return "Successfully logged in";
    } else {
      throw new Exception();

    }
  }
  return "error";
}
}
