package com.example.Userdb.CreateUser;

import lombok.Data;
import org.springframework.data.annotation.Id;

import javax.persistence.Entity;

@Entity
public class LoginDetails {
    @Id
    private  String id;
    private String UserName;
    private String password;

    public LoginDetails() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public LoginDetails(String UserName, String password) {
        this.UserName = UserName;
        this.password = password;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

