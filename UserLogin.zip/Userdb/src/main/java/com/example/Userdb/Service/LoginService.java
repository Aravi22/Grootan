package com.example.Userdb.Service;

import com.example.Userdb.CreateUser.LoginDetails;

public interface LoginService {
    public String login(LoginDetails loginDetails) throws Exception;


    }
