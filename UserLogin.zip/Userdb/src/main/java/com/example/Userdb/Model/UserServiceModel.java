package com.example.Userdb.Model;

import javax.persistence.Column;
import javax.persistence.Table;

@Table(name="userdb")
public class UserServiceModel {
    @Column(name="userId")
    private String userId;
@Column(name="phoneNumber")
    private String phoneNumber;
@Column(name="password")
    private String password;
@Column(name="role")
    private String role;



}
